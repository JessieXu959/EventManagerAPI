import json
from typing import List, Dict

class EventFileManager:
    FILE_PATH = "events.json"

    @classmethod
    def read_events_from_file(cls) -> List[Dict]:
        """Reads events from a file and returns them as a list of dictionaries."""
        try:
            with open(cls.FILE_PATH, 'r', encoding='utf-8') as file:
                return json.load(file)
        except FileNotFoundError:
            return []  
        except json.JSONDecodeError:
            return []  

    @classmethod
    def write_events_to_file(cls, events: List[Dict]) -> None:
        """Writes a list of dictionaries as events to a file."""
        with open(cls.FILE_PATH, 'w', encoding='utf-8') as file:
            json.dump(events, file, ensure_ascii=False, indent=4)